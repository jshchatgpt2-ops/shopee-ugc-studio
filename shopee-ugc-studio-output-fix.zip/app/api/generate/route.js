import {NextResponse} from 'next/server';
import crypto from 'crypto';
export const runtime='nodejs';

function cloudinaryConfig(){
  const raw=process.env.CLOUDINARY_URL;
  if(!raw) throw new Error('CLOUDINARY_URL is not configured in Vercel.');
  const u=new URL(raw);
  return {apiKey:u.username,apiSecret:u.password,cloudName:u.hostname};
}

async function uploadToCloudinary(file){
  if(!file)return null;
  const {apiKey,apiSecret,cloudName}=cloudinaryConfig();
  const timestamp=Math.floor(Date.now()/1000);
  const folder='shopee-ugc-studio';
  const signature=crypto.createHash('sha1').update(`folder=${folder}&timestamp=${timestamp}${apiSecret}`).digest('hex');
  const fd=new FormData();
  fd.append('file',file);
  fd.append('api_key',apiKey);
  fd.append('timestamp',String(timestamp));
  fd.append('folder',folder);
  fd.append('signature',signature);
  const r=await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`,{method:'POST',body:fd});
  const j=await r.json();
  if(!r.ok||!j.secure_url) throw new Error(j?.error?.message||'Cloudinary image upload failed.');
  return j.secure_url;
}

export async function POST(req){
 try{
  if(!process.env.MAGICA_API_KEY)return NextResponse.json({error:'MAGICA_API_KEY is not configured in Vercel.'},{status:500});
  const f=await req.formData(); const product=f.get('product'),avatar=f.get('avatar'),background=f.get('background');
  if(!product)return NextResponse.json({error:'Product image is required.'},{status:400});
  const urls=(await Promise.all([avatar?uploadToCloudinary(avatar):null,uploadToCloudinary(product),background?uploadToCloudinary(background):null])).filter(Boolean);
  const prompt=`Create a ${f.get('style')} Shopee affiliate UGC promotional video. Mode: ${f.get('mode')}. Camera: ${f.get('angle')}. Background: ${f.get('bg')}. Product category: ${f.get('category')}. Voice language: ${f.get('voice')}. Tone: ${f.get('tone')}. Custom details: ${f.get('details')||'none'}. Avoid: ${f.get('negative')}. Preserve the supplied product and avatar appearance. If a background reference is supplied, use it as the scene environment while keeping the person and product natural, realistic and clearly visible.`;
  const r=await fetch('https://api.magica.com/api/v1/nodes/gemini_omni_flash/run',{method:'POST',headers:{'Content-Type':'application/json','Authorization':`Bearer ${process.env.MAGICA_API_KEY}`},body:JSON.stringify({nodeType:'gemini_omni_flash',input:{image_urls:urls,prompt,duration:Number(f.get('duration')||10),aspect_ratio:f.get('ratio')||'9:16'},subModelId:'gemini-omni-flash-reference-to-video'})});
  const j=await r.json();
  if(!r.ok||!j.runId)return NextResponse.json({error:j.error||j.message||'Magica generation failed'},{status:r.status||500});
  return NextResponse.json({runId:j.runId});
 }catch(e){return NextResponse.json({error:e.message},{status:500})}
}
